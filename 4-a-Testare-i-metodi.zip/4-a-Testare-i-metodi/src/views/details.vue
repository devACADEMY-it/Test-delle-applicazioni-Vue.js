<template>
  <FormCreateEntry :init="init" @submit="submit" />
</template>

<script>
import FormCreateEntry from "@/components/FormCreateEntry";

export default {
  components: {
    FormCreateEntry
  },
  data() {
    return {
      id: this.$route.params.id,
      init: {}
    };
  },
  methods: {
    async submit(payload) {
      await this.$store.dispatch("update", {
        id: this.id,
        date: payload.date,
        hours: payload.hours,
        comment: payload.comment
      });

      this.$router.replace("/");
    }
  },
  async created() {
    await this.$store.dispatch("find");

    const entry = this.$store.getters.getEntry(parseInt(this.id));

    this.init = entry;
  }
};
</script>

<style lang="scss" scoped></style>
