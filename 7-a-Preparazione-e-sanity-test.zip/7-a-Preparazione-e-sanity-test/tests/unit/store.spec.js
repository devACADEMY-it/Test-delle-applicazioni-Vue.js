import { store } from "@/store";

describe("store", () => {
  test("sanity test", () => {
    expect(store.state).not.toBeUndefined();
    expect(store.mutations).not.toBeUndefined();
    expect(store.actions).not.toBeUndefined();
    expect(store.getters).not.toBeUndefined();
    expect(store.modules).not.toBeUndefined();
  });
});
