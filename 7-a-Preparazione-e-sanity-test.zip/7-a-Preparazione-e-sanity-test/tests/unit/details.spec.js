import { shallowMount } from "@vue/test-utils";
import flushPromises from "flush-promises";
import Details from "@/views/details";

describe("details.vue", () => {
  test("id initlized by params.id", () => {
    const id = 123;

    const wrapper = shallowMount(Details, {
      mocks: {
        $store: {
          dispatch: () => {},
          getters: {
            getEntry: () => {}
          }
        },
        $route: {
          params: {
            id
          }
        }
      }
    });

    expect(wrapper.vm.$data.id).toBe(id);
  });

  test("title contains current id", () => {
    const id = 123;

    const wrapper = shallowMount(Details, {
      mocks: {
        $store: {
          dispatch: () => {},
          getters: {
            getEntry: () => {}
          }
        },
        $route: {
          params: {
            id
          }
        }
      }
    });

    expect(wrapper.find("h1.title").text()).toContain(id);
  });

  test("getEntry called with current id", async () => {
    const id = 123;
    const wrapper = shallowMount(Details, {
      mocks: {
        $store: {
          dispatch: async () => {},
          getters: {
            getEntry: () => {}
          }
        },
        $route: {
          params: {
            id
          }
        }
      }
    });

    jest.spyOn(wrapper.vm.$store.getters, "getEntry");

    await flushPromises();

    expect(wrapper.vm.$store.getters.getEntry).toHaveBeenCalledWith(id);
  });
});
