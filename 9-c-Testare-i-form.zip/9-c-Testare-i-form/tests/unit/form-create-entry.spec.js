import { shallowMount } from "@vue/test-utils";
import FormCreateEntry from "@/components/FormCreateEntry";

describe("FormCreateEntry.vue", () => {
  function createWrapper(date, comment, hours) {
    date = date || new Date().toISOString().slice(0, 10);
    comment = comment || "";
    hours = hours || 0;

    const wrapper = shallowMount(FormCreateEntry, {
      propsData: {
        init: {
          date,
          comment,
          hours
        }
      }
    });

    return wrapper;
  }

  test("check button disabled", () => {
    const wrapper = createWrapper();

    expect(wrapper.find("button[type='submit']").attributes().disabled).toBe(
      "disabled"
    );
  });

  test("check button enabled", () => {
    const wrapper = createWrapper(undefined, "abc");

    expect(wrapper.find("button[type='submit']").attributes().disabled).toBe(
      undefined
    );
  });

  test("check reset method", () => {
    const item = {
      date: new Date(0).toISOString().slice(0, 10),
      comment: "abc",
      hours: 7
    };

    const wrapper = createWrapper(item.date, item.comment, item.hours);

    expect(wrapper.vm.$data.date).toBe(item.date);
    expect(wrapper.vm.$data.comment).toBe(item.comment);
    expect(wrapper.vm.$data.hours).toBe(item.hours);

    wrapper.vm.reset();

    expect(wrapper.vm.$data.date).toBe(new Date().toISOString().slice(0, 10));
    expect(wrapper.vm.$data.comment).toBe("");
    expect(wrapper.vm.$data.hours).toBe(0);
  });

  test("check submit method", () => {
    const wrapper = createWrapper(undefined, "abc", 7);

    jest.spyOn(wrapper.vm, "reset");

    wrapper.vm.submit();

    expect(wrapper.vm.reset).toHaveBeenCalled();
  });

  test("at submit calls submit method", () => {
    const wrapper = createWrapper(undefined, "abc", 7);

    jest.spyOn(wrapper.vm, "submit");

    wrapper.find("form").trigger("submit");

    expect(wrapper.vm.submit).toHaveBeenCalled();
  });

  test("at reset calls reset method", () => {
    const wrapper = createWrapper(undefined, "abc", 7);

    jest.spyOn(wrapper.vm, "reset");

    wrapper.find("form").trigger("reset");

    expect(wrapper.vm.reset).toHaveBeenCalled();
  });

  test("submit button click emit 'submit' event", () => {
    const wrapper = createWrapper(undefined, "abc", 7);

    wrapper.find("form").trigger("submit");

    expect(wrapper.emitted("submit")).toHaveLength(1);
  });

  test("v-model date", () => {
    const wrapper = createWrapper(undefined, "abc", 7);
    const value = "2019-01-01";

    wrapper.find("input[type='date']").setValue(value);

    expect(wrapper.vm.$data.date).toBe(value);
  });

  test("v-model hours", () => {
    const wrapper = createWrapper(undefined, "abc", 7);
    const value = 10;

    wrapper.find("input[type='number']").setValue(value);

    expect(wrapper.vm.$data.hours).toBe(value);
  });

  test("v-model comment", () => {
    const wrapper = createWrapper(undefined, "abc", 7);
    const value = "prova";

    wrapper.find("textarea").setValue(value);

    expect(wrapper.vm.$data.comment).toBe(value);
  });

  test("v-model isPublic", () => {
    const wrapper = createWrapper(undefined, "abc", 7);
    const value = true;

    wrapper.find("input[type='checkbox']").setChecked(value);

    expect(wrapper.vm.$data.isPublic).toBe(value);
  });
});
