describe("navigation", () => {
  it("navigate to /gallery", () => {
    cy.visit("/");
    cy.get(".navbar-menu .navbar-item:nth-child(2)").click();
    cy.location("pathname").should("eq", "/gallery");
  });

  it("navigate to /abc", () => {
    cy.visit("/");
    cy.get(".navbar-menu .navbar-item:nth-child(3)").click();
    cy.location("pathname").should("eq", "/abc");
  });

  it("navigate to /abc", () => {
    cy.visit("/gallery");
    cy.get(".navbar-menu .navbar-item:nth-child(1)").click();
    cy.location("pathname").should("eq", "/");
  });
});
