it("sanity test", () => {
  cy.visit("/");
  cy.get("form");
  cy.get("h1.title");
  cy.get(".column.sidebar");
});
