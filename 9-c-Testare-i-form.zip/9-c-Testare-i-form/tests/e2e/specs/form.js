it("submit time entry", () => {
  const date = "2019-12-13";
  const comment = "abc";
  const hours = Math.floor(Math.random() * 10) + 1;

  cy.visit("/");

  cy.get("input[type='date']").type(date);
  cy.get("textarea").type(comment);
  cy.get("input[type='number']").type(hours);

  cy.get("form").submit();

  cy.get(".main .box:last-child small:last-child").should(
    "have.text",
    `Hours: ${hours}`
  );
});
