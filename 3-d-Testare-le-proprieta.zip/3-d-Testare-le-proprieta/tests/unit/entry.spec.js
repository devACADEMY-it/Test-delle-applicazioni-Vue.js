import { shallowMount } from "@vue/test-utils";
import Entry from "@/components/Entry";

describe("Entry.vue", () => {
  const wrapper = shallowMount(Entry, {
    propsData: {
      id: 1,
      date: "17/11/2019",
      comment: "prova",
      hours: 10
    },
    mocks: {
      $d: () => "17/11/2019"
    }
  });

  test("renders id", () => {
    expect(wrapper.find(".media-content > .content > p > small").text()).toBe(
      "#1"
    );
  });

  test("renders date", () => {
    expect(
      wrapper
        .find(".media-content > .content > p > small:nth-of-type(2)")
        .text()
    ).toBe("17/11/2019");
  });

  test("renders comment", () => {
    expect(wrapper.find(".media-content > .content > p").text()).toContain(
      "prova"
    );
  });

  test("renders hours", () => {
    expect(wrapper.find(".media-content > small").text()).toBe("Hours: 10");
  });
});
