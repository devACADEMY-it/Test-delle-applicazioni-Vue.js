import Vue from "vue";
import Vuex from "vuex";
import http from "axios";
import clicks from "./store.clicks";

Vue.use(Vuex);

export const store = {
  strict: process.env.NODE_ENV !== "production",

  state: {
    entries: []
  },
  mutations: {
    SET_ENTRIES(state, payload) {
      state.entries = payload;
    },
    PUSH_ENTRY(state, payload) {
      state.entries.push(payload);
    },
    UPDATE_ENTRY(state, payload) {
      const target = state.entries.findIndex(e => e.id === payload.id);

      state.entries.splice(target, 1, payload);
    },
    REMOVE_ENTRY(state, payload) {
      state.entries = state.entries.filter(e => e.id !== payload);
    }
  },
  actions: {
    // eslint-disable-next-line no-unused-vars
    async find(context, payload) {
      const response = await http.get("http://localhost:3000/entries");

      context.commit("SET_ENTRIES", response.data);
    },
    async create(context, payload) {
      const { date, hours, comment } = payload;

      const response = await http.post("http://localhost:3000/entries", {
        date,
        hours,
        comment
      });

      context.commit("PUSH_ENTRY", response.data);
    },
    async update(context, payload) {
      const { id, date, hours, comment } = payload;

      const response = await http.put(`http://localhost:3000/entries/${id}`, {
        date,
        hours,
        comment
      });

      context.commit("UPDATE_ENTRY", response.data);
    },
    async remove(context, payload) {
      await http.delete(`http://localhost:3000/entries/${payload}`);

      context.commit("REMOVE_ENTRY", payload);
    }
  },
  getters: {
    // eslint-disable-next-line no-unused-vars
    totalHours: (state, getters) =>
      state.entries.reduce((count, entry) => {
        count += entry.hours;
        return count;
      }, 0),
    // eslint-disable-next-line no-unused-vars
    getEntry: (state, getters) => id => state.entries.find(e => e.id === id)
  },

  modules: {
    clicks
  }
};

export default new Vuex.Store(store);
