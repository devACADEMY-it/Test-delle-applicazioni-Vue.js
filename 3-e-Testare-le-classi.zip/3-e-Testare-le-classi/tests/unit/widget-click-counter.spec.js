import { shallowMount } from "@vue/test-utils";
import WidgetClickCounter from "@/components/WidgetClickCounter";

describe("WidgetClickCounter.vue", () => {
  test("add has-text-danger if count > 10", () => {
    const wrapper = shallowMount(WidgetClickCounter, {
      mocks: {
        $store: {
          state: {
            clicks: {
              count: 11
            }
          }
        }
      }
    });

    expect(wrapper.find(".card-content > .content").classes()).toContain(
      "has-text-danger"
    );
  });

  test("remove has-text-danger if count < 10", () => {
    const wrapper = shallowMount(WidgetClickCounter, {
      mocks: {
        $store: {
          state: {
            clicks: {
              count: 9
            }
          }
        }
      }
    });

    expect(
      wrapper
        .find(".card-content > .content")
        .classes()
        .find(c => c === "has-text-danger")
    ).toBeUndefined();
  });
});
