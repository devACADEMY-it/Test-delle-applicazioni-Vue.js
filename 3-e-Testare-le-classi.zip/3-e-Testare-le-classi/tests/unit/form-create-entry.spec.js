import { shallowMount } from "@vue/test-utils";
import FormCreateEntry from "@/components/FormCreateEntry";

describe("FormCreateEntry.vue", () => {
  test("check button disabled", () => {
    const wrapper = shallowMount(FormCreateEntry, {
      propsData: {
        init: {
          date: new Date().toISOString().slice(0, 10),
          comment: "",
          hours: 0
        }
      }
    });

    expect(wrapper.find("button[type='submit']").attributes().disabled).toBe(
      "disabled"
    );
  });

  test("check button enabled", () => {
    const wrapper = shallowMount(FormCreateEntry, {
      propsData: {
        init: {
          date: new Date().toISOString().slice(0, 10),
          comment: "abc",
          hours: 0
        }
      }
    });

    expect(wrapper.find("button[type='submit']").attributes().disabled).toBe(
      undefined
    );
  });
});
