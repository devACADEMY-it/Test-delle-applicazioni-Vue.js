import { shallowMount } from "@vue/test-utils";
import flushPromises from "flush-promises";
import Details from "@/views/details";

describe("details.vue", () => {
  function createWrapper(id) {
    const wrapper = shallowMount(Details, {
      mocks: {
        $store: {
          dispatch: () => {},
          getters: {
            getEntry: () => {}
          }
        },
        $route: {
          params: {
            id
          }
        }
      }
    });

    return wrapper;
  }
  test("id initlized by params.id", () => {
    const id = 123;
    const wrapper = createWrapper(id);

    expect(wrapper.vm.$data.id).toBe(id);
  });

  test("title contains current id", () => {
    const id = 123;
    const wrapper = createWrapper(id);

    expect(wrapper.find("h1.title").text()).toContain(id);
  });

  test("getEntry called with current id", async () => {
    const id = 123;
    const wrapper = createWrapper(id);

    jest.spyOn(wrapper.vm.$store.getters, "getEntry");

    await flushPromises();

    expect(wrapper.vm.$store.getters.getEntry).toHaveBeenCalledWith(id);
  });
});
