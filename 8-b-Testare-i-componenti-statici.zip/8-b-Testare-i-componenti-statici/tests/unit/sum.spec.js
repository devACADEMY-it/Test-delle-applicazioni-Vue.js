import sum from "../../src/assets/sum";

test("test sum", () => {
  expect(sum(1, 1)).toEqual(2);
});
