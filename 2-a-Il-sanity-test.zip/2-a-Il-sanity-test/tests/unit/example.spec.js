describe("Item.vue", () => {
  test("Sanity Test", () => {
    setTimeout(() => {
      expect(true).toBe(false);
    }, 100);
  });

  test("Sanity Test 2", () => {
    setTimeout(() => {
      expect(true).toBe(false);
    }, 100);
  });
});
