import { mount } from "@vue/test-utils";
import Navbar from "@/components/Navbar";

test("renders home link", () => {
  const wrapper = mount(Navbar, { stubs: ["router-link"] });

  expect(
    wrapper.vm.$el.querySelector(".navbar-start > .navbar-item").textContent
  ).toEqual("Home");
});
