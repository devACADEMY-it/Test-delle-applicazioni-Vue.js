import { shallowMount } from "@vue/test-utils";
import WidgetClickCounter from "@/components/WidgetClickCounter";

describe("WidgetClickCounter.vue", () => {
  test("renders correct progress bar width", () => {
    const count = 50;
    const wrapper = shallowMount(WidgetClickCounter, {
      mocks: {
        $store: {
          state: {
            clicks: {
              count
            }
          }
        }
      }
    });

    expect(wrapper.find(".progress-bar > .bar").element.style.width).toBe(
      `${count}%`
    );
  });

  test("add has-text-danger if count > 10", () => {
    const wrapper = shallowMount(WidgetClickCounter, {
      mocks: {
        $store: {
          state: {
            clicks: {
              count: 11
            }
          }
        }
      }
    });

    expect(wrapper.find(".card-content > .content").classes()).toContain(
      "has-text-danger"
    );
  });

  test("remove has-text-danger if count < 10", () => {
    const wrapper = shallowMount(WidgetClickCounter, {
      mocks: {
        $store: {
          state: {
            clicks: {
              count: 9
            }
          }
        }
      }
    });

    expect(
      wrapper
        .find(".card-content > .content")
        .classes()
        .find(c => c === "has-text-danger")
    ).toBeUndefined();
  });
});
