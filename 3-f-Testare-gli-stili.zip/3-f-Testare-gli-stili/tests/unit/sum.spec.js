import sum from "../../src/assets/sum";

test("test sum", () => {
  const a = 1;
  expect(sum(1, 1)).toEqual(2);
});
