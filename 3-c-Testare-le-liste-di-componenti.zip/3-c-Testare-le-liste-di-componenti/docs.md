# Strumenti di sviluppo

## Vue CLI

### Installazione

`npm i @vue/cli -g`

Richiede nodejs 8.11+

### Funzionalità

- Generazione di progetti
- Installazione di plugin
- Comandi per compilare e avviare l'applicazione
- Interfaccia grafica opzionale

```bat
C:\Users\Giovanni>vue
Usage: vue <command> [options]

Options:
  -V, --version                              output the version number
  -h, --help                                 output usage information

Commands:
  create [options] <app-name>                create a new project powered by vue-cli-service
  add [options] <plugin> [pluginOptions]     install a plugin and invoke its generator in an already created project
  invoke [options] <plugin> [pluginOptions]  invoke the generator of a plugin in an already created project
  inspect [options] [paths...]               inspect the webpack config in a project with vue-cli-service
  serve [options] [entry]                    serve a .js or .vue file in development mode with zero config
  build [options] [entry]                    build a .js or .vue file in production mode with zero config
  ui [options]                               start and open the vue-cli ui
  init [options] <template> <app-name>       generate a project from a remote template (legacy API, requires @vue/cli-init)
  config [options] [value]                   inspect and modify the config
  upgrade [semverLevel]                      upgrade vue cli service / plugins (default semverLevel: minor)
  info                                       print debugging information about your environment

  Run vue <command> --help for detailed usage of given command.
```

## Vue Dev Tools

### Installazione

- Estensione per Chrome
- Estensione per Firefox
- App dedicata

### Funzionalità

- Gestione dei componenti
- Analisi di Vuex
- Registro eventi
- Mappa delle rotte
- Report sulle performance

## IDE / Editor

### Più popolari

- Visual Studio Code
- WebStorm
- Atom
- Sublime Text

### Estensioni

- Indispensabili
  - Vetur
  - ESLint
  - Prettier - Code formatter
  - Debugger for Chrome
- Estetiche / Utilità
  - Git Graph
  - vscode-faker
  - Italian Language Pack for Visual Studio Code
  - One Dark Pro
  - Material Icon Theme

### Impostazioni

```json
// Indispensabili

{
  "git.autofetch": true,
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "vetur.validation.template": false,
  "eslint.autoFixOnSave": true,
  "eslint.validate": [
    {
      "language": "html",
      "autoFix": true
    },
    {
      "language": "vue",
      "autoFix": true
    },
    {
      "language": "javascript",
      "autoFix": true
    },
    {
      "language": "javascriptreact",
      "autoFix": true
    }
  ]
}
```

```json
// Estetiche / Utilità

{
  "editor.tabSize": 2,
  "editor.renderWhitespace": "all",
  "editor.wordWrap": "on",
  "editor.renderControlCharacters": true,
  "editor.renderIndentGuides": true,
  "workbench.startupEditor": "newUntitledFile",
  "files.hotExit": "off",
  "window.restoreWindows": "none",
  "workbench.colorTheme": "One Dark Pro",
  "workbench.iconTheme": "material-icon-theme",
  "files.insertFinalNewline": true,
  "files.trimTrailingWhitespace": true,
  "editor.cursorSmoothCaretAnimation": true,
  "breadcrumbs.enabled": false
}
```

### Configurazione debug

```json
{
  "type": "chrome",
  "request": "launch",
  "name": "vuejs: chrome",
  "url": "http://localhost:8080",
  "webRoot": "${workspaceFolder}/src",
  "breakOnLoad": true,
  "sourceMapPathOverrides": {
    "webpack:///./src/*": "${webRoot}/*",
    "webpack:///src/*": "${webRoot}/*",
    "webpack:///*": "*",
    "webpack:///./~/*": "${webRoot}/node_modules/*"
  }
}
```

# Definizione di un componente

## Registrazione di un componente

### Globale

```js
📁 src/main.js

import MyComponentName from "@/components/MyComponentName";

Vue.component("my-component-name", MyComponentName);
Vue.component("MyComponentName", MyComponentName);
```

### Locale

```html
📁 src/App.Vue

<template>
  <my-component-name />
  <MyComponentName />
</template>

<script>
  import MyComponentName from "@/components/MyComponentName";

  export default {
    name: "App",
    components: {
      MyComponentName
    }
  };
</script>

<style></style>
```

## Single File Component

```html
📁 src/components/FooBar.vue

<template>
  <p>{{ foo }}</p>
</template>

<script>
  export default {
    name: "FooBar",

    data() {
      return {
        foo: "bar"
      };
    }
  };
</script>

<style lang="scss" scoped></style>
```

## String e template literal

```js
Vue.component("FooBar", {
  template: `
    <p>{{ foo }}</p>
  `,
  data() {
    return {
      foo: "bar"
    };
  }
});
```

## x-template

```js
📁 src/main.js

Vue.component("FooBar", {
  template: "#foo-bar",
  data() {
    return {
      foo: "bar"
    };
  }
});
```

```html
📁 public/index.html

<!DOCTYPE html>
<html lang="en">
  <head>
    ...
  </head>
  <body>
    ...

    <script type="text/x-template" id="foo-bar">
      <p>{{ foo }}</p>
    </script>

    ...
  </body>
</html>
```

## inline-template

```js
📁 src/main.js

Vue.component("FooBar", {
  data() {
    return {
      foo: "bar"
    };
  }
});
```

```html
📁 src/App.vue
<template>
  <div id="app">
    <FooBar inline-template>
      <p>{{ foo }}</p>
    </FooBar>
  </div>
</template>

<script>
  ...
</script>

<style lang="scss" scoped></style>
```

## JSX

```js
📁 src/main.js

Vue.component("FooBar", {
  render() {
    return <p>{ this.foo }</p>
  },
  data() {
    return {
      foo: "bar"
    };
  }
});
```

### Sintassi

#### Contenuto

```jsx
render() {
  return <p>hello</p>
}
```

```jsx
render() {
  return <p>hello { this.message }</p>
}
```

```jsx
render() {
  return <input />
}
```

```jsx
import MyComponent from "./my-component";

export default {
  render() {
    return <MyComponent>hello</MyComponent>;
  }
};
```

#### Attributi e Proprietà

```jsx
render() {
  return <input type="email" />
}
```

```jsx
render() {
  return <input
    type="email"
    placeholder={this.placeholderText}
  />
}
```

```jsx
render() {
  const inputAttrs = {
    type: 'email',
    placeholder: 'Enter your email'
  }

  return <input {...{ attrs: inputAttrs }} />
}
```

#### Slots

```jsx
render() {
  return (
    <MyComponent>
      <header slot="header">header</header>
      <footer slot="footer">footer</footer>
    </MyComponent>
  )
}
```

```jsx
render() {
  const scopedSlots = {
    header: () => <header>header</header>,
    footer: () => <footer>footer</footer>
  }

  return <MyComponent scopedSlots={scopedSlots} />
}
```

#### Direttive

```jsx
<input vModel={this.newTodoText} />
```

```jsx
<input vModel_trim={this.newTodoText} />
```

```jsx
<input vOn:click={this.newTodoText} />
```

```jsx
<input vOn:click_stop_prevent={this.newTodoText} />
```

```jsx
<p domPropsInnerHTML={html} />
```

## render function

```js
📁 src/main.js

Vue.component("FooBar", {
  render(el) {
    return el("p", {}, [this.foo])
  },
  data() {
    return {
      foo: "bar"
    };
  }
});
```

## Componenti dinamici

```html
📁 src/App.vue

<template>
  <Component :is="name"></Component>
</template>

<script>
  export default {
    name: "App",

    data() {
      return {
        name: "FooBar"
      };
    }
  };
</script>

<style lang="scss" scoped></style>
```

## Componenti asincroni

```js
Vue.component("async-example", function(resolve, reject) {
  setTimeout(function() {
    resolve({
      template: "<div>I am async!</div>"
    });
  }, 1000);
});

Vue.component("async-webpack-example", function(resolve) {
  require(["./my-async-component"], resolve);
});

Vue.component("async-webpack-example", () => import("./my-async-component"));

new Vue({
  components: {
    "my-component": () => import("./my-async-component")
  }
});

const AsyncComponent = () => ({
  component: import("./MyComponent.vue"),
  loading: LoadingComponent,
  error: ErrorComponent,
  delay: 200,
  timeout: 3000
});
```

# Routing

## Cos’è il routing client side

### Lato Server

- Ci vengono restituiti solo i dati necessari, ne più ne meno
- Ottimizzato per i motori di ricerca
- Ogni richiesta causa un aggiornamento dell'intera pagina

### Lato Client

- Il caricamento iniziale richiede solitamente più tempo ma le successive richieste sono più rapide perchè vengono elaborati meno dati
- Meno ottimizzato per i motori di ricerca
- Transizioni e animazioni tra le pagine senza ricaricare l'intera pagina

### Implementazioni

- Con hash
  - https://example.com/#/user/123/profile
- HTML5 History API
  - https://example.com/user/123/profile

```

📄 .htaccess

<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

```
📄 nginx

location / {
  try_files $uri /index.html;
}
```

## Vue-router

### Funzionalità

- Mappare rotte e rotte innestate
- Configurazione modulare basata su componenti
- Rotte con parametri, query, caratteri jolly
- Transizioni tra le pagine
- Controllo della navigazione
- Classi css automatiche sui link di navigazione
- Modalità HTML5 e modalità hash
- Scorrimento personalizzabile

### Installazione

- Manuale
- In fase di generazione del progetto
- Come plugin `vue add router`

### Navigazione

```html
<router-link to="/home">Home</router-link>
<a href="/home">Home</a>

<router-link :to="{ path: '/home' }">Home</router-link>
<a href="/home">Home</a>

<router-link :to="{ name: 'user', params: { userId: 123 }}">User</router-link>
<a href="/user/123">Home</a>

<router-link :to="{ path: '/register', query: { plan: 'private' }}">
  Register
</router-link>
<a href="/register?plan=private">Home</a>

<router-link :to="{ path: '/abc'}" replace></router-link>

<router-link :to="{ path: 'relative/path'}" append></router-link>

<router-link to="/foo" tag="li">foo</router-link>
<li>foo</li>

<router-link
  to="/home"
  active-class="router-link-active"
  exact-active-class="router-link-exact-active"
  exact
  event="click"
>
  Home
</router-link>
```

### Visualizzazione

```html
<router-view></router-view>

<router-view name="sidebar"></router-view>
```

## Route dinamiche

```js
📁 src/router.js

import Home from "./views/Home.vue";
import NotFound from "./views/404.vue";

const User = {
  template: "<div>User {{ $route.params.id }}</div>",
  methods: {
    printCurrentRoute() {
      console.log(this.$route)
    }
  }
}

const router = new VueRouter({
  routes: [
    { path: "/", component: Home },
    { path: "/user/:id", component: User,
      children: [
        {
          path: '',
          component: UserHome
        },
        {
          path: 'profile',
          component: UserProfile
        },
        {
          path: 'posts',
          component: UserPosts
        }
      ]
    },
    { path: "/user-*", component: User },

    { path: "*", component: NotFound }
  ]
})
```

## Route innestate

```html
<div class="wrapper">
  <div class="sidebar">
    <router-view name="sidebar"></router-view>
  </div>
  <div class="main">
    <router-view></router-view>
  </div>
</div>
```

```js
const router = new VueRouter({
  routes: [
    {
      path: "/",
      components: {
        default: Home,
        sidebar: Sidebar
      }
    }
  ]
});
```

## Navigazione programmatica

- push(location, onComplete?, onAbort?)
- replace(location, onComplete?, onAbort?)
- go(n)

```js
this.$router.push("/home"); // /home

this.$router.push({ path: "/home" }); // /home

this.$router.push({ name: "user", params: { userId: "123" } }); // /user/123

this.$router.push({ path: "register", query: { plan: "private" } }); // /register?plan=private

this.$router.push({ path: `/user/${userId}` });

this.$router.push({ path: "/user", params: { userId: "123" } }); // -> /user

router.go(1);

router.go(-1);

router.go(3);

router.go(-100);
router.go(100);
```

## Route con nome

### Definizione

```js
const router = new VueRouter({
  routes: [
    {
      path: "/user/:userId",
      name: "user",
      component: User
    }
  ]
});
```

### Utilizzo nei link

```html
<router-link :to="{ name: 'user', params: { userId: 123 }}">User</router-link>
```

### Utilizzo nel codice

```js
this.$router.push({ name: "user", params: { userId: 123 } });
```

## Global Navigation Guards

```js
const router = new VueRouter({ ... })

router.beforeEach((to, from, next) => {
  next()

  next(false)

  next('/')

  next({ path: '/' })
})

router.afterEach((to, from) => {

})
```

```js
const router = new VueRouter({
  routes: [
    {
      path: "/foo",
      component: Foo,
      beforeEnter: (to, from, next) => {
        next();
      }
    }
  ]
});
```

## In Component Navigation Guards

### Definizione

```html
<template>
  ...
</template>

<script>
  export default {
    beforeRouteEnter(to, from, next) {
      next(vm => {
        console.log(vm.$data.foo);
      });
    },
    beforeRouteUpdate(to, from, next) {},
    beforeRouteLeave(to, from, next) {
      const answer = window.confirm("Sei sicuro di voler uscire?");

      if (answer) {
        next();
      } else {
        next(false);
      }
    },
    data() {
      return {
        foo: "bar"
      };
    }
  };
</script>

<style></style>
```

### Flusso

1. beforeRouteLeave nei componenti disattivati
2. beforeEach globale
3. beforeRouteUpdate nei componenti riutilizzati
4. beforeEnter sulla rotta
5. beforeRouteEnter nei nuovi componenti
6. beforeResolve globale
7. afterEach globale

## Code splitting

```js
import Vue from "vue";
import Router from "vue-router";
import Home from "./views/Home.vue";

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: "/",
      name: "home",
      component: Home
    },
    {
      path: "/about",
      name: "about",
      component: () =>
        import(/* webpackChunkName: "about" */ "./views/About.vue") // => about.[hash].js
    }
  ]
});
```

# Gestione dello stato globale

## Cos’è lo stato globale

<img src="https://miro.medium.com/max/1728/0*Z4BWPeaDXOob_qFs.png" width="50%" />

<img src="https://miro.medium.com/max/1923/0*UeFfKsm6fvgtXoKz.png" width="50%" />

## Vuex

### Installazione

- Manuale
- In fase di generazione del progetto
- Come plugin `vue add vuex`

### Concetti

- State
- Mutations
- Actions
- Getters
- Modules

### Funzionamento

<img src="https://miro.medium.com/max/2000/0*p45Yk1OoJkXFTFjy.png" width="50%" />

<img src="https://miro.medium.com/max/1200/0*5BcWxyQW7ai1JsVd.gif" width="50%" />

## State

```js
📁 src/store.js

export default new Vuex.Store({
  strict: process.env.NODE_ENV !== "production",

  state: {
    count: 123
  },
  mutations: {},
  actions: {},
  getters: {},

  modules: {}
});
```

```html
<template>
  <p>{{ count }}</p>
</template>

<script>
  import { mapState } from "vuex";

  export default {
    computed: {
      count() {
        return this.$store.state.count;
      },
      ...mapState(["count"]),
      ...mapState({
        count: state => state.count,
        countAlias: "count"
      })
    }
  };
</script>

<style lang="scss" scoped></style>
```

## Mutations

```js
📁 src/store.js

export default new Vuex.Store({
  strict: process.env.NODE_ENV !== "production",

  state: {
    count: 123
  },
  mutations: {
    INC_COUNT(state, payload) {
      state.count++
    },
    SET_COUNT(state, payload) {
      state.count = payload
    },
  },
  actions: {},
  getters: {},

  modules: {}
});
```

```html
<template>
  <p>
    {{ count }}
    <button @click="incCount()"></button>
    <button @click="setCount()"></button>

    <button @click="increment()"></button>
    <button @click="incrementBy(1)"></button>
    <button @click="add()"></button>
  </p>
</template>

<script>
  import { mapMutations } from "vuex";

  export default {
    methods: {
      incCount() {
        this.$store.commit("INC_COUNT");
      },
      setCount() {
        this.$store.commit("SET_COUNT", 5);
      },
      ...mapMutations([
        "increment", // `this.increment()` => `this.$store.commit('increment')`
        "incrementBy" // `this.incrementBy(amount)` => `this.$store.commit('incrementBy', amount)`
      ]),
      ...mapMutations({
        add: "increment" // `this.add()` => `this.$store.commit('increment')`
      })
    }
  };
</script>

<style lang="scss" scoped></style>
```

### ⚠ Reattività nelle mutations

- Vue.set(obj, 'newProp', 123)
- state.obj = { ...state.obj, newProp: 123 }

## Actions

```js
📁 src/store.js

export default new Vuex.Store({
  strict: process.env.NODE_ENV !== "production",

  state: {
    count: 123
  },
  mutations: {
    SET_COUNT(state, payload) {
      state.count = payload
    },
  },
  actions: {
    async getCount(context, payload) {
      const response = await http.get("...")

      context.commit("SET_COUNT", response.data)
    }
  },
  getters: {},

  modules: {}
});
```

```html
<template>
  <p>
    {{ count }}
    <button @click="getCount()"></button>
  </p>
</template>

<script>
  import { mapActions } from "vuex";

  export default {
    methods: {
      async getCount() {
        try {
          await this.$store.dispatch("getCount");
        } catch (error) {
          console.error(error);
        }
      },
      ...mapActions([
        "increment", // `this.increment()` => `this.$store.dispatch('increment')`
        "incrementBy" // `this.incrementBy(amount)` => `this.$store.dispatch('incrementBy', amount)`
      ]),
      ...mapActions({
        add: "increment" // `this.add()` => `this.$store.dispatch('increment')`
      })
    }
  };
</script>

<style lang="scss" scoped></style>
```

### Context

```
{
  state,      // `store.state`
  commit,     // `store.commit`
  dispatch,   // `store.dispatch`
  getters,    // `store.getters`

  rootState,  // `store.state`
  rootGetters // `store.getters`
}
```

## Getters

```js
📁 src/store.js

export default new Vuex.Store({
  strict: process.env.NODE_ENV !== "production",

  state: {
    todos: [
      { id: 1, text: '...', done: true },
      { id: 2, text: '...', done: false }
    ]
  },
  mutations: {
  },
  actions: {
  },
  getters: {
    todosCount: (state, getters) => {
      return state.todos.length
    },
    doneTodos: (state, getters) => {
      return state.todos.filter(todo => todo.done)
    },
    getTodoById: (state, getters) => (id) => {
      return state.todos.find(todo => todo.id === id)
    }
  },

  modules: {}
});
```

```html
<template>
  <p>
    {{ count }}
  </p>
</template>

<script>
  import { mapGetters } from "vuex";

  export default {
    computed: {
      count() {
        return this.$store.getters.todosCount;
      },
      ...mapGetters(["doneTodos"]), // this.doneTodos => this.$store.getters.doneTodos
      ...mapGetters({
        done: "doneTodos" // this.done => this.$store.getters.doneTodos
      })
    }
  };
</script>

<style lang="scss" scoped></style>
```

## Modules

```js
📁 src/store.js

export default new Vuex.Store({
  strict: process.env.NODE_ENV !== "production",

  state: {
    count: 123
  },
  mutations: {},
  actions: {},
  getters: {},

  modules: {
    account: {
      namespaced: true,

      state: { ... }, // -> state.account.abc
      getters: {
        isAdmin () { ... } // -> getters['account/isAdmin']
      },
      actions: {
        login () { ... } // -> dispatch('account/login')
      },
      mutations: {
        login () { ... } // -> commit('account/login')
      }
    }
  }
});
```

# i18n

## Installazione

- In fase di generazione
- Plugin: `vue add i18n`
- Manuale: `npm i vue-i18n`

```js
import Vue from "vue";
import VueI18n from "vue-i18n";

Vue.use(VueI18n);

const app = new Vue({
  i18n: new VueI18n({
    locale: "en",
    messages: {
      msg: "hello world"
    }
  })
}).$mount("#app");
```

## Utilizzo

### Statico

```js
const messages = {
  en: {
    message: {
      hello: "hello world"
    }
  }
};
```

```html
<p>{{ $t('message.hello') }}</p>
```

```html
<p>hello world</p>
```

### Nomi dinamici

```js
const messages = {
  en: {
    message: {
      hello: "{msg} world"
    }
  }
};
```

```html
<p>{{ $t('message.hello', { msg: 'hello' }) }}</p>
```

```html
<p>hello world</p>
```

### Liste dinamiche

```js
const messages = {
  en: {
    message: {
      hello: "{0} world"
    }
  }
};
```

```html
<p>{{ $t('message.hello', ['hello']) }}</p>
<p>{{ $t('message.hello', {'0': 'hello'}) }}</p>
```

```html
<p>hello world</p>
```

### HTML

```js
const messages = {
  en: {
    message: {
      hello: "hello <br> world"
    }
  }
};
```

```html
<p v-html="$t('message.hello')"></p>
```

```html
<p>
  hello <br />
  world
</p>
```

## Gestione del plurale

```js
const messages = {
  en: {
    apple: "no apples | one apple | {n} apples"
  }
};
```

```html
<p>{{ $tc('apple', 0) }}</p>
<p>{{ $tc('apple', 1) }}</p>
<p>{{ $tc('apple', 10) }}</p>
<p>{{ $tc('apple', 100, { n: 'too many' }) }}</p>
```

```html
<p>no apples</p>
<p>one apple</p>
<p>10 apples</p>
<p>too many apples</p>
```

## Gestione delle date

```js
const dateTimeFormats = {
  "en-US": {
    short: {
      year: "numeric",
      month: "short",
      day: "numeric"
    },
    long: {
      year: "numeric",
      month: "short",
      day: "numeric",
      weekday: "short",
      hour: "numeric",
      minute: "numeric"
    }
  },
  "ja-JP": {
    short: {
      year: "numeric",
      month: "short",
      day: "numeric"
    },
    long: {
      year: "numeric",
      month: "short",
      day: "numeric",
      weekday: "short",
      hour: "numeric",
      minute: "numeric",
      hour12: true
    }
  }
};

const i18n = new VueI18n({
  dateTimeFormats
});

new Vue({
  i18n
}).$mount("#app");
```

```html
<div id="app">
  <p>{{ $d(new Date(), 'short') }}</p>
  <p>{{ $d(new Date(), 'long', 'ja-JP') }}</p>
</div>
```

```html
<div id="app">
  <p>Apr 19, 2017</p>
  <p>2017年4月19日(水) 午前2:19</p>
</div>
```

![alt](https://i.imgur.com/eFaAcMq.png)

## Gestione dei numeri

```js
const numberFormats = {
  "en-US": {
    currency: {
      style: "currency",
      currency: "USD"
    }
  },
  "ja-JP": {
    currency: {
      style: "currency",
      currency: "JPY",
      currencyDisplay: "symbol"
    }
  }
};

const i18n = new VueI18n({
  numberFormats
});

new Vue({
  i18n
}).$mount("#app");
```

```html
<div id="app">
  <p>{{ $n(100, 'currency') }}</p>
  <p>{{ $n(100, 'currency', 'ja-JP') }}</p>
</div>
```

```html
<div id="app">
  <p>$100.00</p>
  <p>￥100</p>
</div>
```

## Registrazione delle traduzioni

```js
const i18n = new VueI18n({
  locale: "en",
  messages: {
    en: {
      message: {
        hello: "hello world"
      }
    }
  }
});

const HelloWorld = {
  template: `
    <div class="container">
      <p>HelloWorld locale messages: {{ $t("message.hello") }}</p>
    </div>
   `,
  i18n: {
    messages: {
      en: { message: { hello: "hello universe" } }
    }
  }
};

new Vue({
  i18n,
  components: {
    HelloWorld
  }
}).$mount("#app");
```

```html
<div class="container">
  <p>HelloWorld locale messages: hello universe</p>
</div>
```

```html
<template>
  <p>{{ $t("hello") }}</p>
</template>

<script>
  export default {
    name: "HelloI18n"
  };
</script>

<i18n>
  { "en": { "hello": "Hello i18n in SFC!" } }
</i18n>
```
