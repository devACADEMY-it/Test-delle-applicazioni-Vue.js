import { shallowMount } from "@vue/test-utils";
import Navbar from "@/components/Navbar";

describe("Navbar.vue", () => {
  const wrapper = shallowMount(Navbar, { stubs: ["router-link"] });

  test("renders home link and url", () => {
    const item = {
      text: "Home",
      to: "/"
    };

    const element = wrapper.find(".navbar-start > .navbar-item:nth-child(1)");

    expect(element.text()).toBe(item.text);
    expect(element.attributes().to).toBe(item.to);
  });

  test("renders gallery link and url", () => {
    const item = {
      text: "Gallery",
      to: "/gallery"
    };

    const element = wrapper.find(".navbar-start > .navbar-item:nth-child(2)");

    expect(element.text()).toBe(item.text);
    expect(element.attributes().to).toBe(item.to);
  });

  test("renders 404 link and url", () => {
    const item = {
      text: "404",
      to: "/abc"
    };

    const element = wrapper.find(".navbar-start > .navbar-item:nth-child(3)");

    expect(element.text()).toBe(item.text);
    expect(element.attributes().to).toBe(item.to);
  });
});
