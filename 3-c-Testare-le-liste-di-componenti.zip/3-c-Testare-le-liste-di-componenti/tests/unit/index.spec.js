import { shallowMount } from "@vue/test-utils";
import Index from "@/views/index";
import Entry from "@/components/Entry";

describe("index.vue", () => {
  test("renders correct amount of time entries", () => {
    const entries = [
      {
        id: 1,
        date: "17/11/2019",
        comment: "prova",
        hours: 10
      },
      {
        id: 2,
        date: "17/11/2019",
        comment: "prova",
        hours: 10
      },
      {
        id: 3,
        date: "17/11/2019",
        comment: "prova",
        hours: 10
      }
    ];

    const wrapper = shallowMount(Index, {
      mocks: {
        $t: () => "",
        $tc: () => "",
        $n: () => "",
        $store: {
          state: {
            entries
          },
          dispatch: () => {}
        }
      }
    });

    expect(wrapper.findAll(Entry).length).toBe(entries.length);
  });
});
