<template>
  <form @submit.prevent="submit" @reset.prevent="reset">
    <div class="field is-horizontal">
      <div class="field-body">
        <div class="field">
          <label class="label">Date</label>
          <div class="control">
            <input v-model="date" class="input" type="date" />
          </div>
        </div>
        <div class="field">
          <label class="label">Hours</label>
          <div class="control">
            <input v-model.number="hours" class="input" type="number" />
          </div>
        </div>
      </div>
    </div>
    <div class="field is-horizontal">
      <div class="field-body">
        <div class="field">
          <label class="label">Comment</label>
          <div class="control">
            <textarea v-model="comment" class="textarea"></textarea>
          </div>
        </div>
      </div>
    </div>
    <div class="field is-grouped">
      <p class="control">
        <button
          class="button is-primary"
          type="submit"
          :disabled="isCommentEmpty"
        >
          Submit
        </button>
      </p>
      <p class="control">
        <button class="button is-light" type="reset">Cancel</button>
      </p>
    </div>
  </form>
</template>

<script>
export default {
  name: "FormCreateEntry",
  props: {
    init: {
      type: Object,
      default: () => ({
        date: new Date().toISOString().slice(0, 10),
        comment: "",
        hours: 0
      })
    }
  },
  data() {
    return {
      date: null,
      comment: null,
      hours: null
    };
  },
  watch: {
    init: {
      // eslint-disable-next-line no-unused-vars
      handler(newValue, oldValue) {
        this.date = newValue.date;
        this.comment = newValue.comment;
        this.hours = newValue.hours;
      },
      immediate: true,
      deep: true
    }
  },
  computed: {
    isCommentEmpty() {
      return this.comment === "";
    }
  },
  methods: {
    submit() {
      this.$emit("submit", {
        date: this.date,
        comment: this.comment,
        hours: this.hours
      });

      this.reset();
    },
    reset() {
      this.date = new Date().toISOString().slice(0, 10);
      this.comment = "";
      this.hours = 0;
    }
  }
};
</script>

<style lang="scss" scoped></style>
