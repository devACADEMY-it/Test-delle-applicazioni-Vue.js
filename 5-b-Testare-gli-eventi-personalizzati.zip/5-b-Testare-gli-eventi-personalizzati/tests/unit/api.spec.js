import { shallowMount } from "@vue/test-utils";
import Api from "@/components/Api";
import http from "axios";
import flushPromises from "flush-promises";

const response = {
  data: {
    data: {
      children: [
        {
          data: {
            id: 0,
            thumbnail: ""
          }
        }
      ]
    }
  }
};

jest.spyOn(http, "get").mockImplementation(async () => response);

describe("Api.js", () => {
  test("get data from api", async () => {
    const wrapper = shallowMount(Api, {
      propsData: {
        url: "https://www.reddit.com/r/aww.json"
      },
      scopedSlots: {
        default: "<p></p>"
      }
    });

    await flushPromises();

    expect(wrapper.vm.$data.response).toBe(response);
  });
});
