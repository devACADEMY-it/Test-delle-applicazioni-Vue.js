import { shallowMount } from "@vue/test-utils";
import FormCreateEntry from "@/components/FormCreateEntry";

describe("FormCreateEntry.vue", () => {
  test("check button disabled", () => {
    const wrapper = shallowMount(FormCreateEntry, {
      propsData: {
        init: {
          date: new Date().toISOString().slice(0, 10),
          comment: "",
          hours: 0
        }
      }
    });

    expect(wrapper.find("button[type='submit']").attributes().disabled).toBe(
      "disabled"
    );
  });

  test("check button enabled", () => {
    const wrapper = shallowMount(FormCreateEntry, {
      propsData: {
        init: {
          date: new Date().toISOString().slice(0, 10),
          comment: "abc",
          hours: 0
        }
      }
    });

    expect(wrapper.find("button[type='submit']").attributes().disabled).toBe(
      undefined
    );
  });

  test("check reset method", () => {
    const item = {
      date: new Date(0).toISOString().slice(0, 10),
      comment: "abc",
      hours: 7
    };

    const wrapper = shallowMount(FormCreateEntry, {
      propsData: {
        init: item
      }
    });

    expect(wrapper.vm.$data.date).toBe(item.date);
    expect(wrapper.vm.$data.comment).toBe(item.comment);
    expect(wrapper.vm.$data.hours).toBe(item.hours);

    wrapper.vm.reset();

    expect(wrapper.vm.$data.date).toBe(new Date().toISOString().slice(0, 10));
    expect(wrapper.vm.$data.comment).toBe("");
    expect(wrapper.vm.$data.hours).toBe(0);
  });

  test("check submit method", () => {
    const wrapper = shallowMount(FormCreateEntry, {
      propsData: {
        init: {
          date: new Date(0).toISOString().slice(0, 10),
          comment: "abc",
          hours: 7
        }
      }
    });

    jest.spyOn(wrapper.vm, "reset");

    wrapper.vm.submit();

    expect(wrapper.vm.reset).toHaveBeenCalled();
  });

  test("at submit calls submit method", () => {
    const wrapper = shallowMount(FormCreateEntry, {
      propsData: {
        init: {
          date: new Date(0).toISOString().slice(0, 10),
          comment: "abc",
          hours: 7
        }
      }
    });

    jest.spyOn(wrapper.vm, "submit");

    wrapper.find("form").trigger("submit");

    expect(wrapper.vm.submit).toHaveBeenCalled();
  });

  test("at reset calls reset method", () => {
    const wrapper = shallowMount(FormCreateEntry, {
      propsData: {
        init: {
          date: new Date(0).toISOString().slice(0, 10),
          comment: "abc",
          hours: 7
        }
      }
    });

    jest.spyOn(wrapper.vm, "reset");

    wrapper.find("form").trigger("reset");

    expect(wrapper.vm.reset).toHaveBeenCalled();
  });

  test("submit button click emit 'submit' event", () => {
    const wrapper = shallowMount(FormCreateEntry, {
      propsData: {
        init: {
          date: new Date(0).toISOString().slice(0, 10),
          comment: "abc",
          hours: 7
        }
      }
    });

    wrapper.find("form").trigger("submit");

    expect(wrapper.emitted("submit")).toHaveLength(1);
  });
});
