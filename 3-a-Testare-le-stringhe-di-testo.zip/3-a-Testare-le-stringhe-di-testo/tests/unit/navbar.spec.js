import { shallowMount } from "@vue/test-utils";
import Navbar from "@/components/Navbar";

describe("Navbar.vue", () => {
  test("renders home link", () => {
    const wrapper = shallowMount(Navbar, { stubs: ["router-link"] });

    expect(
      wrapper.find(".navbar-start > .navbar-item:nth-child(1)").text()
    ).toBe("Home");
  });

  test("renders gallery link", () => {
    const wrapper = shallowMount(Navbar, { stubs: ["router-link"] });

    expect(
      wrapper.find(".navbar-start > .navbar-item:nth-child(2)").text()
    ).toBe("Gallery");
  });

  test("renders 404 link", () => {
    const wrapper = shallowMount(Navbar, { stubs: ["router-link"] });

    expect(
      wrapper.find(".navbar-start > .navbar-item:nth-child(3)").text()
    ).toBe("404");
  });
});
