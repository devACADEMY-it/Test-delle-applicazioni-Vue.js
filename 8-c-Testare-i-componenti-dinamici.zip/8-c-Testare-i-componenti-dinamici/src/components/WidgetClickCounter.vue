<template>
  <div class="card" @click="count++">
    <header class="card-header">
      <p class="card-header-title">Click Counter</p>
    </header>
    <div class="card-content">
      <div class="content" :class="{ 'has-text-danger': count > 10 }">
        {{ count }}
      </div>
      <div class="progress-bar">
        <div class="bar" :style="{ width: progress }"></div>
      </div>
      <div class="has-text-info">seconds: {{ seconds }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "WidgetClickCounter",
  data() {
    return {
      seconds: 0,
      timer: false
    };
  },
  methods: {
    start() {
      this.timer = setInterval(() => {
        this.seconds++;
      }, 1000);
    },
    stop() {
      clearInterval(this.timer);
      this.seconds = 0;
      this.timer = false;
    }
  },
  computed: {
    progress() {
      return `${Math.min(this.count, 100)}%`;
    },
    count: {
      get() {
        return this.$store.state.clicks.count;
      },
      // eslint-disable-next-line no-unused-vars
      set(value) {
        this.$store.commit("clicks/ADD");
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.progress-bar {
  border: 1px solid #333;

  .bar {
    background: #f00;
    height: 5px;
  }
}
</style>
