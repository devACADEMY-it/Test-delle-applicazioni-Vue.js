module.exports = {
  configureWebpack: {
    devtool: "source-map"
  },

  runtimeCompiler: true,

  pluginOptions: {
    i18n: {
      locale: "en",
      fallbackLocale: "en",
      localeDir: "locales",
      enableInSFC: true
    }
  }
};
