import { shallowMount, createLocalVue, mount } from "@vue/test-utils";
import Index from "@/views/index";
import Entry from "@/components/Entry";
import store from "@/store";
import i18n from "@/i18n";

const localVue = createLocalVue();
localVue.use(store);
localVue.use(i18n);

describe("index.vue", () => {
  const entries = [
    {
      id: 1,
      date: "17/11/2019",
      comment: "prova",
      hours: 10
    },
    {
      id: 2,
      date: "17/11/2019",
      comment: "prova",
      hours: 10
    },
    {
      id: 3,
      date: "17/11/2019",
      comment: "prova",
      hours: 10
    }
  ];

  const wrapper = shallowMount(Index, {
    localVue,
    i18n,
    store
  });

  test("Entry receive correct props", () => {
    wrapper.findAll(Entry).wrappers.forEach((wrapper, index) => {
      expect(wrapper.props().id).toBe(entries[index].id);
      expect(wrapper.props().date).toBe(entries[index].date);
      expect(wrapper.props().comment).toBe(entries[index].comment);
      expect(wrapper.props().hours).toBe(entries[index].hours);
    });
  });

  test("renders correct amount of time entries", () => {
    expect(wrapper.findAll(Entry).length).toBe(0);
  });

  test("redirect to details on Entry click", () => {
    const entry = { id: 1, date: "01/01/2019", comment: "abc", hours: 7 };
    const wrapper = mount(Index, {
      mocks: {
        $t: () => {},
        $n: () => {},
        $tc: () => {},
        $d: () => {},
        $store: {
          state: {
            entries: [entry]
          },
          dispatch: async () => {}
        },
        $router: {
          push: () => {}
        }
      }
    });

    jest.spyOn(wrapper.vm.$router, "push");

    wrapper.find(Entry).trigger("click");

    expect(wrapper.vm.$router.push).toHaveBeenCalledWith(
      `/details/${entry.id}`
    );
  });
});
