import { shallowMount, createLocalVue, RouterLinkStub } from "@vue/test-utils";
import Navbar from "@/components/Navbar";
import router from "@/router";

jest.spyOn(window.console, "log").mockImplementation(() => {});

describe("Navbar.vue", () => {
  function createWrapper() {
    const localVue = createLocalVue();

    localVue.use(router);

    const wrapper = shallowMount(Navbar, { localVue, router });

    return wrapper;
  }

  test("render links and urls", () => {
    const wrapper = shallowMount(Navbar, {
      stubs: {
        RouterLink: RouterLinkStub
      }
    });

    const links = wrapper.findAll(RouterLinkStub);

    expect(links.at(0).props().to).toBe("/");
    expect(links.at(0).text()).toBe("Home");

    expect(links.at(1).props().to).toBe("/gallery");
    expect(links.at(1).text()).toBe("Gallery");

    expect(links.at(2).props().to).toBe("/abc");
    expect(links.at(2).text()).toBe("404");
  });

  test("renders home link and url", () => {
    const wrapper = createWrapper();
    const item = {
      text: "Home",
      to: "/"
    };
    const element = wrapper.find(".navbar-start > .navbar-item:nth-child(1)");

    expect(element.text()).toBe(item.text);
    expect(element.attributes().to).toBe(item.to);
  });

  test("renders gallery link and url", () => {
    const wrapper = createWrapper();
    const item = {
      text: "Gallery",
      to: "/gallery"
    };
    const element = wrapper.find(".navbar-start > .navbar-item:nth-child(2)");

    expect(element.text()).toBe(item.text);
    expect(element.attributes().to).toBe(item.to);
  });

  test("renders 404 link and url", () => {
    const wrapper = createWrapper();
    const item = {
      text: "404",
      to: "/abc"
    };
    const element = wrapper.find(".navbar-start > .navbar-item:nth-child(3)");

    expect(element.text()).toBe(item.text);
    expect(element.attributes().to).toBe(item.to);
  });
});
