import { shallowMount, createLocalVue } from "@vue/test-utils";
import Entry from "@/components/Entry";
import i18n from "@/i18n";

describe("Entry.vue", () => {
  function createWrapper() {
    const localVue = createLocalVue();
    localVue.use(i18n);

    const wrapper = shallowMount(Entry, {
      propsData: {
        id: 1,
        date: "11-17-2019",
        comment: "prova",
        hours: 10
      },
      localVue,
      i18n
    });

    return wrapper;
  }

  test("renders id", () => {
    const wrapper = createWrapper();

    expect(wrapper.find(".media-content > .content > p > small").text()).toBe(
      "#1"
    );
  });

  test("renders date", () => {
    const wrapper = createWrapper();

    expect(
      wrapper
        .find(".media-content > .content > p > small:nth-of-type(2)")
        .text()
    ).toBe("11/17/19");
  });

  test("renders comment", () => {
    const wrapper = createWrapper();

    expect(wrapper.find(".media-content > .content > p").text()).toContain(
      "prova"
    );
  });

  test("renders hours", () => {
    const wrapper = createWrapper();

    expect(wrapper.find(".media-content > small").text()).toBe("Hours: 10");
  });

  test("calls remove on button click", () => {
    const wrapper = createWrapper();

    jest.spyOn(wrapper.vm, "remove");
    wrapper.find("button.delete").trigger("click");
    expect(wrapper.vm.remove).toHaveBeenCalled();
  });

  test("box click emit 'click' event", () => {
    const wrapper = createWrapper();

    wrapper.find(".box").trigger("click");
    wrapper.find(".box").trigger("click");

    expect(wrapper.emitted("click")).toHaveLength(2);
  });

  test("remove method emit 'remove' event", () => {
    const wrapper = createWrapper();

    wrapper.vm.remove();

    expect(wrapper.emitted("remove")).toHaveLength(1);
  });
});
