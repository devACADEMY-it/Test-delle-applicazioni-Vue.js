import { store } from "@/store";
import http from "axios";
import flushPromises from "flush-promises";

describe("store", () => {
  test("sanity test", () => {
    expect(store.state).not.toBeUndefined();
    expect(store.mutations).not.toBeUndefined();
    expect(store.actions).not.toBeUndefined();
    expect(store.getters).not.toBeUndefined();
    expect(store.modules).not.toBeUndefined();
  });
});

describe("mutations", () => {
  test("SET_ENTRIES", () => {
    const state = {
      entries: []
    };

    const payload = [
      {
        id: 1,
        date: "11-17-2019",
        comment: "prova",
        hours: 10
      }
    ];

    store.mutations.SET_ENTRIES(state, payload);

    expect(state.entries).toEqual(payload);
  });

  test("PUSH_ENTRY", () => {
    const state = {
      entries: []
    };

    const payload = {
      id: 1,
      date: "11-17-2019",
      comment: "prova",
      hours: 10
    };

    store.mutations.PUSH_ENTRY(state, payload);

    expect(state.entries.length).toBe(1);
  });

  test("UPDATE_ENTRY", () => {
    const state = {
      entries: [
        {
          id: 1,
          date: "11-17-2019",
          comment: "prova",
          hours: 10
        }
      ]
    };

    const payload = {
      id: 1,
      date: "11-17-2019",
      comment: "prova",
      hours: 15
    };

    store.mutations.UPDATE_ENTRY(state, payload);

    const entry = state.entries.find(({ id }) => payload.id === id);

    expect(entry.hours).toBe(payload.hours);
  });

  test("REMOVE_ENTRY", () => {
    const state = {
      entries: [
        {
          id: 1,
          date: "11-17-2019",
          comment: "prova",
          hours: 15
        }
      ]
    };

    const payload = 1;

    store.mutations.REMOVE_ENTRY(state, payload);

    const entry = store.state.entries.find(({ id }) => id === payload);

    expect(entry).toBeUndefined();
  });
});

describe("actions", () => {
  test("find", async () => {
    const response = {
      data: [
        {
          id: 1,
          date: "11-17-2019",
          comment: "prova",
          hours: 15
        },
        {
          id: 2,
          date: "11-17-2019",
          comment: "prova",
          hours: 10
        }
      ]
    };

    jest.spyOn(http, "get").mockImplementation(async () => response);

    const context = {
      commit: jest.fn()
    };

    store.actions.find(context);

    await flushPromises();

    expect(context.commit).toHaveBeenCalledWith("SET_ENTRIES", response.data);
  });

  test("create", async () => {
    const payload = {
      id: 2,
      date: "11-17-2019",
      comment: "prova",
      hours: 10
    };

    jest
      .spyOn(http, "post")
      .mockImplementation(async () => ({ data: payload }));

    const context = {
      commit: jest.fn()
    };

    store.actions.create(context, payload);

    await flushPromises();

    expect(context.commit).toHaveBeenCalledWith("PUSH_ENTRY", payload);
  });

  test("update", async () => {
    const payload = {
      id: 2,
      date: "11-17-2019",
      comment: "prova",
      hours: 10
    };

    jest.spyOn(http, "put").mockImplementation(async () => ({ data: payload }));

    const context = {
      commit: jest.fn()
    };

    store.actions.update(context, payload);

    await flushPromises();

    expect(context.commit).toHaveBeenCalledWith("UPDATE_ENTRY", payload);
  });

  test("remove", async () => {
    const payload = 1;

    jest.spyOn(http, "delete").mockImplementation(async () => {});

    const context = {
      commit: jest.fn()
    };

    store.actions.remove(context, payload);

    await flushPromises();

    expect(context.commit).toHaveBeenCalledWith("REMOVE_ENTRY", payload);
  });
});

describe("getters", () => {
  test("totalHours", () => {
    const state = {
      entries: [
        {
          id: 1,
          date: "11-17-2019",
          comment: "prova",
          hours: 15
        },
        {
          id: 2,
          date: "11-17-2019",
          comment: "prova",
          hours: 10
        }
      ]
    };

    let totalHours = 0;

    for (const entry of state.entries) {
      totalHours += entry.hours;
    }

    expect(store.getters.totalHours(state)).toBe(totalHours);
  });

  test("getEntry", () => {
    const state = {
      entries: [
        {
          id: 1,
          date: "11-17-2019",
          comment: "prova",
          hours: 15
        },
        {
          id: 2,
          date: "11-17-2019",
          comment: "prova",
          hours: 10
        }
      ]
    };

    const target = 1;
    const entry = state.entries.find(({ id }) => id === target);

    expect(store.getters.getEntry(state)(target)).toEqual(entry);
  });
});
